using System;
using System.Windows.Forms;

public class Program
{
    [STAThread]
    public static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new MemoryGameForm());  // Make sure this references MemoryGameForm, not Form1
    }
}
