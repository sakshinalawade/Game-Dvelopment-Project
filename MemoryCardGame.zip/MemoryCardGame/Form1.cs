using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

public class MemoryGameForm : Form
{
    private Button[,] buttons = new Button[4, 4];
    private List<int> cardValues = new List<int>();
    private int firstCardIndex = -1;
    private int secondCardIndex = -1;
    private int moveCount = 0;
    private int matchedPairs = 0;
    private System.Windows.Forms.Timer gameTimer;
    private Label ImgMoves;
    private Label timer;
        private Label heading; 

    private int elapsedTime = 0;
    private Image[] cardImages = {
        Image.FromFile("images/img1.jpg"), 
        Image.FromFile("images/img2.jpg"), 
        Image.FromFile("images/img3.jpg"), 
        Image.FromFile("images/img4.jpg"), 
        Image.FromFile("images/img5.jpg"), 
        Image.FromFile("images/img6.jpg"), 
        Image.FromFile("images/img7.jpg"), 
        Image.FromFile("images/img8.jpg")
    };
     private Image backgroundimage = Image.FromFile("images/background_image.jpg");
    public MemoryGameForm()
    {
        InitializeComponent();
        InitializeGame();
    }

    private void InitializeComponent()
    {
        this.Text = "Memory Game";
        this.Size = new Size(700, 700);
        heading = new Label()
        {
            Location = new Point(220, 20), 
            Text = "Memory Game",          
            Font = new Font("Arial", 24, FontStyle.Bold),
            ForeColor = Color.Red,      
            AutoSize = true               
        };
        this.BackgroundImage = backgroundimage;
        this.BackgroundImageLayout = ImageLayout.Stretch;
        this.Controls.Add(heading);
        ImgMoves = new Label() { Location = new Point(5, 5), Text = "Moves: 0" };
        timer = new Label() { Location = new Point(500, 20), Text = "Time: 0s" };
        this.Controls.Add(ImgMoves);
        this.Controls.Add(timer);
    }

    private void InitializeGame()
    {
        cardValues = new List<int> { 0, 1, 2, 3, 4, 5, 6, 7, 0, 1, 2, 3, 4, 5, 6, 7 };
        Random rand = new Random();
        cardValues = cardValues.OrderBy(x => rand.Next()).ToList();

        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                buttons[i, j] = new Button()
                {
                    Location = new Point(140 * j + 80, 140 * i + 80),
                    Size = new Size(150, 150),
                    Text = "",
                    BackColor = Color.Gray
                };
                buttons[i, j].Click += Card_Click;
                this.Controls.Add(buttons[i, j]);
            }
        }

        gameTimer = new System.Windows.Forms.Timer(); 
        gameTimer.Interval = 1000;
        gameTimer.Tick += (sender, e) =>
        {
            elapsedTime++;
            timer.Text = "Time: " + elapsedTime + "s";
        };
        gameTimer.Start();
    }

   private void Card_Click(object sender, EventArgs e)
{
    Button clickedButton = (Button)sender;
    int row = (clickedButton.Top - 60) / 120;  
    int col = (clickedButton.Left - 60) / 120;  
    int cardIndex = row * 4 + col;  

    if (buttons[row, col].Text != "" || cardIndex == firstCardIndex)
        return;

    buttons[row, col].Image = cardImages[cardValues[cardIndex]];

    if (firstCardIndex == -1)
    {
        firstCardIndex = cardIndex;
    }
    else
    {
        secondCardIndex = cardIndex;
        moveCount++;
        ImgMoves.Text = "Moves: " + moveCount;

        if (cardValues[firstCardIndex] == cardValues[secondCardIndex])
        {
            matchedPairs++;
            if (matchedPairs == 8) 
            {
                gameTimer.Stop();
                MessageBox.Show($"Game Over! You won in {elapsedTime} seconds and {moveCount} moves.");
            }
        }
        else
        {
            Thread.Sleep(400); 
            buttons[(firstCardIndex / 4), (firstCardIndex % 4)].Image = null;
            buttons[(firstCardIndex / 4), (firstCardIndex % 4)].BackColor = Color.Gray;
            buttons[(secondCardIndex / 4), (secondCardIndex % 4)].Image = null;
            buttons[(secondCardIndex / 4), (secondCardIndex % 4)].BackColor = Color.Gray;
        }

        firstCardIndex = -1;
        secondCardIndex = -1;
    }
}

}