using System;
using System.Drawing;
using System.Windows.Forms;

namespace BrickBreakerGame
{
    public partial class Form1 : Form
    {
        private const int PaddleWidth = 100;
        private const int PaddleHeight = 15;
        private const int BallSize = 10;
        private const int BrickWidth = 50;
        private const int BrickHeight = 25;
        private const int Rows = 5;
        private const int Columns = 10;

        private Rectangle paddle;
        private Rectangle ball;
        private int ballDx = 4;
        private int ballDy = -4;
        private bool[,] bricks;
        private System.Windows.Forms.Timer gameTimer;
        private int score;

        public Form1()
        {
            this.Text = "Brick Breaker Game";
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.ClientSize = new Size(500, 600);
            paddle = new Rectangle(200, 500, PaddleWidth, PaddleHeight); 
            ball = new Rectangle(250, 400, BallSize, BallSize); 
            bricks = new bool[Rows, Columns];
            score = 0;
            for (int i = 0; i < Rows; i++)
            {
                for (int j = 0; j < Columns; j++)
                {
                    bricks[i, j] = true;
                }
            }
            gameTimer = new System.Windows.Forms.Timer(); 
            gameTimer.Interval = 15; 
            gameTimer.Tick += GameTimer_Tick;
            gameTimer.Start(); 
            this.KeyDown += Form1_KeyDown;
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            ball.X += ballDx;
            ball.Y += ballDy;
            if (ball.Left <= 0 || ball.Right >= this.ClientSize.Width)
            {
                ballDx = -ballDx; 
            }

            if (ball.Top <= 0)
            {
                ballDy = -ballDy;
            }

            if (ball.IntersectsWith(paddle))
            {
                ballDy = -ballDy; 
                score += 10;
            }

            for (int i = 0; i < Rows; i++)
            {
                for (int j = 0; j < Columns; j++)
                {
                    if (bricks[i, j] && ball.IntersectsWith(new Rectangle(j * BrickWidth, i * BrickHeight, BrickWidth, BrickHeight)))
                    {
                        bricks[i, j] = false;
                        ballDy = -ballDy;
                        score += 10;
                    }
                }
            }
            if (ball.Bottom >= this.ClientSize.Height)
            {
                gameTimer.Stop();
                MessageBox.Show($"Game Over! Your Score: {score}", "Game Over", MessageBoxButtons.OK);
                Application.Exit();
            }

            this.Invalidate();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left && paddle.Left > 0)
            {
                paddle.X -= 10;
            }
            if (e.KeyCode == Keys.Right && paddle.Right < this.ClientSize.Width)
            {
                paddle.X += 10; 
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;

            g.FillRectangle(Brushes.Blue, paddle);

            g.FillEllipse(Brushes.Red, ball);

            for (int i = 0; i < Rows; i++)
            {
                for (int j = 0; j < Columns; j++)
                {
                    
                    if (bricks[i, j])
                    {
                        int brickX = j * BrickWidth;
                        int brickY = i * BrickHeight;
                        g.FillRectangle(Brushes.Green, new Rectangle(brickX, brickY, BrickWidth, BrickHeight));
                        g.DrawRectangle(Pens.Black, new Rectangle(brickX, brickY, BrickWidth, BrickHeight));
                    }
                }
            }
            g.DrawString($"Score: {score}", new Font("Arial", 12), Brushes.Black, new PointF(10, 10));
        }
    }
}
