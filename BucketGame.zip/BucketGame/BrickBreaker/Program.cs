using System;
using System.Windows.Forms;

namespace BrickBreakerGame
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            // Set application to use Windows Forms and start with Form1
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());  // Ensure Form1 is initialized here
        }
    }
}
