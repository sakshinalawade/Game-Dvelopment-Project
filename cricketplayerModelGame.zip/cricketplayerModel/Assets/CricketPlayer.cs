using UnityEditor;
using UnityEngine;

public class CreateCricketCharacter : MonoBehaviour
{
    public Transform rightArm;
    public Transform leftArm;
    public Transform body;
    public Transform leftLeg;
    public Transform rightLeg;

    void Start()
    {
        CreateCharacter();
    }

    void CreateCharacter()
    {
        // Create the main GameObject for the character (Gani)
        GameObject gani = new GameObject("Gani");

        // Create the body parts (head, body, arms, legs)

        // Body (torso)
        GameObject bodyObj = GameObject.CreatePrimitive(PrimitiveType.Cube);
        bodyObj.name = "Body";
        bodyObj.transform.localScale = new Vector3(0.5f, 1.5f, 0.3f);  // Torso size
        bodyObj.transform.position = new Vector3(0, 1, 0);  // Position
        bodyObj.transform.parent = gani.transform;  // Make the body a child of Gani
        body = bodyObj.transform;  // Store the reference for later use

        // Head
        GameObject head = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        head.name = "Head";
        head.transform.localScale = new Vector3(0.6f, 0.6f, 0.6f);  // Head size
        head.transform.position = new Vector3(0, 2.2f, 0);  // Position
        head.transform.parent = gani.transform;

        // Left Arm
        GameObject leftArmObj = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        leftArmObj.name = "LeftArm";
        leftArmObj.transform.localScale = new Vector3(0.2f, 0.8f, 0.2f);  // Arm size
        leftArmObj.transform.position = new Vector3(-0.8f, 1.5f, 0);  // Position
        leftArmObj.transform.parent = gani.transform;
        leftArm = leftArmObj.transform;  // Store the reference for later use

        // Right Arm
        GameObject rightArmObj = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        rightArmObj.name = "RightArm";
        rightArmObj.transform.localScale = new Vector3(0.2f, 0.8f, 0.2f);  // Arm size
        rightArmObj.transform.position = new Vector3(0.8f, 1.5f, 0);  // Position
        rightArmObj.transform.parent = gani.transform;
        rightArm = rightArmObj.transform;  // Store the reference for later use

        // Left Leg
        GameObject leftLegObj = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        leftLegObj.name = "LeftLeg";
        leftLegObj.transform.localScale = new Vector3(0.3f, 1.0f, 0.3f);  // Leg size
        leftLegObj.transform.position = new Vector3(-0.3f, 0.6f, 0);  // Position
        leftLegObj.transform.parent = gani.transform;
        leftLeg = leftLegObj.transform;  // Store the reference for later use

        // Right Leg
        GameObject rightLegObj = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        rightLegObj.name = "RightLeg";
        rightLegObj.transform.localScale = new Vector3(0.3f, 1.0f, 0.3f);  // Leg size
        rightLegObj.transform.position = new Vector3(0.3f, 0.6f, 0);  // Position
        rightLegObj.transform.parent = gani.transform;
        rightLeg = rightLegObj.transform;  // Store the reference for later use

        // Add materials (You can replace this with an actual material later)
        Material ganiMaterial = new Material(Shader.Find("Standard"));
        ganiMaterial.color = Color.white;  // Default white color for simplicity
        bodyObj.GetComponent<Renderer>().material = ganiMaterial;
        head.GetComponent<Renderer>().material = ganiMaterial;
        leftArmObj.GetComponent<Renderer>().material = ganiMaterial;
        rightArmObj.GetComponent<Renderer>().material = ganiMaterial;
        leftLegObj.GetComponent<Renderer>().material = ganiMaterial;
        rightLegObj.GetComponent<Renderer>().material = ganiMaterial;

        // Optionally, add Gani to a prefab for future reuse
        PrefabUtility.SaveAsPrefabAsset(gani, "Assets/Prefabs/GaniCharacter.prefab");
    }
}
